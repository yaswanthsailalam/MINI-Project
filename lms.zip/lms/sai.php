<?php

$s = $_POST['vehicle1'];
echo $s;

?>