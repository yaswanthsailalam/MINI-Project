<?php
session_start();
$con = mysqli_connect("localhost","root","","lms");
if(!$con)
{
  echo "failed";
}
if(isset($_POST['submit']))
  {
     mysqli_select_db($con, 'lms');  // selecting database//
	$fname   = 	$_POST['Name'];
	$mno     = 	$_POST['MobileNumber'];
	$mbno    = 	$_POST['MobileNumber2'];
	$emailid = 	$_POST['email2'];
	$a   = 	$_SESSION['empid'];
	

	 
     $s="select * from signup where EmployeeId='$a'";  
     $query=mysqli_query($con,$s);
     $row=mysqli_fetch_assoc($query);
     $pass    =  $row['Password'];
     $cpass   =  $row['ConfirmPassword'];  
     print_r($_POST);
	 print_r($_SESSION);
     $s = "UPDATE signup set FirstName='$fname',MobileNumber='$mno',MobileNumber2='$mbno',EmailId='$emailid' where EmployeeId='$a'";
	 $result=mysqli_query($con,$s);
     echo "UPDATED SUCCESFULLY";
}
?>