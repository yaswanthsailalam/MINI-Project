<!DOCTYPE html>
<html>
<body>

<?php
session_start();
if(isset($_POST['submit']))
{//to run PHP script on submit
if(!empty($_POST['check']))
{
// Loop to store and display values of individual checked checkbox.
$con = mysqli_connect("localhost","root","","lms");
if(!$con)
{
  echo "failed";
}
$fname=$_SESSION['name'];

foreach($_POST['check'] as $selected)
{
	
	$selected = explode(' ',$selected);
	
	$k = $selected[0];
	$section = $selected[3];
	$day = $selected[2];
	$date = $selected[4];
	$selected = $selected[1];
	$query = "select * from signup where EmployeeId = '$selected'";
	$a=mysqli_query($con,$query);
	
	$row=mysqli_fetch_assoc($a);
	if(!$row)
		continue;
	$x=$row['FirstName'];
	$s = "insert into requesttable (`FromId`,`FromEmpId`, `ToId`,`ToEmpId`, `Day`, `Date`, `Period`, `Section`, `Status`) values('$_SESSION[Name]','$_SESSION[empid]','$x','$selected','$day','$date','$k','$section','pending')";
	echo $s;
	echo "<br>";
	$query = mysqli_query($con,$s);
	$y=$row['EmailId'];
	
		$sub="E-LEAVE Website";
        $msg="Hello $x ,
			$fname has adjusted the class to you ,
			please login to check the details.
                    THANK YOU";
		
        mail($y,$sub,$msg);
	
}
}
echo "<script>window.location.href='$_SESSION[hp]'</script>";
}
?>
</body>
</html>