<?php
	session_start();
	$con=mysqli_connect('localhost','root','','lms');
	if(!$con)
	{
		echo "problem in connection";
	}
	if (isset($_POST['log']))
	{
		$name=$_POST['name'];
		$pass=$_POST['password'];
		$_SESSION['name'] = $name;
		$s="select * from signup where FirstName='$name' and Password='$pass'";
		$query1=mysqli_query($con,$s);
		$query=mysqli_fetch_assoc($query1);
		if(mysqli_num_rows($query1) == 0)
		{
			echo 'Invaid Name Or Password';
		}
		else{
			$_SESSION['empid']=$query['EmployeeId'];
				if($query['UserType']=='HOD')
				{
				echo '<script>window.location.href="hodform.php"</script>';
				$_SESSION['hp']='hodform.php';
			}
		  if($query['UserType']=='FACULTY')
		  {
			echo '<script>window.location.href="facultyform.php"</script>';
			$_SESSION['hp']='facultyform.php';
		  } 
		  if($query['UserType']=='PRINCIPLE')
		  {
			echo '<script>window.location.href="principleform.php"</script>';
			$_SESSION['hp']='principleform.php';
		  }
		}
		
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin:0;
  font-family:cursive;
}

.menu {
  overflow: hidden;
  background-color: #100454;
  margin:0;
  height:78px;
}

.menu a {
  width: 100%;
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding:5px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.menu .icon {
  display: none;
}
.logo{
  display: inline-block;
  float: left;
}
.logo img{
  width:110px;
  height: 76px;
}
.header{
  font-size:18px;
  text-align:center;
  color:black;
  float: left;
  display: inline-block;
  margin-left: 28%;
  font-family:slab serif;
}
.header h1{
  color:white;
}
.bg{
  background-image: url('img.jpeg');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
}

input[type=text], input[type=password] {
  width: 90%;
  padding:5px 5px 5px 5px;
  margin: 4px 0 0 8px;
  display: inline-block;
  border: 2px solid black;
  box-sizing: border-box;
}


}
.head{
  text-align: center;
  color:black;
  background-color: white;

}

button {
  background-color:green;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 50%;
  font-size:22px;
  display:block;
}

button:hover {
  opacity: 0.9;
  transition: (1.1);
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
.container {
  padding: 10px;
}

span.psw {
  float: right;
  padding-top: 16px;
  color:black;
}
label{
  color: black;
  font-size: 25px;

}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
footer{
  background-color: #333;
  margin-bottom: 0;
  width: 100%;
}
.section{
  width:40%;
  height:380px;
  color:black;
  box-shadow:1px 20px 20px 1px black;
  left: 0;
  top: 0;
  background-color:white;
  margin-left:30%;
  margin-top:-50%;
  border-radius:15px;
  padding: 10px;
}
.container{
  background-color:blue;
}
.cont{
  margin-top: 1%;
  display: inline-block;
  float: right;
}
.sidenav {
  height: 60%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  right: 0;
  margin-top:8%;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 100px;
  background-color: floralwhite;
  color: black;
}

.sidenav a {
  padding: 8px 10px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: black;
  display: block;
  transition: 0.4s;
  width: 90%;
  box-shadow: 2px black;
}

.sidenav a:hover {
  color: green;
  background-color:#42f2f5;
  transition: (1.1);
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: -40px;
  font-size: 30px;
  margin-left: 50px;
  color: red;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>


<SCRIPT>
	function ShowAndHide() {
    var x = document.getElementById('SectionName');
    if (x.style.display == 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}
</SCRIPT>

</head>
<body class="bg">
<div class="menu" id="myTopnav">
  <div class="logo">
    <img src="anits.jpeg">
  </div>
  <div class="header">
  <h1>ANITS E-Leave Mangement</h1>
</div>
<div class="cont">
  <a href="#" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</a>
</div>
</div>
<div id="card1" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" style="color:red" onclick="closeNav();document.getElementById('SectionName').style.display='none'">&times;close</a>
   <a href="#home">Home</a><br>
    <a href="signup.php">Sign Up</a><br>
    <a href="#" onclick="myFunction();document.getElementById('SectionName').style.display='block'">Login</a><br>
    <a href="About Us.html">About Us</a>           
</div>
<div ID="SectionName" class="section">
<form action="leavehome.php" method="post">
    <center> <h1> WELCOME </h1></center> 
    <label for="xyz"><b>Name</b></label>
    <input type="text" placeholder="Enter Username Id" name="name" required>
    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>  <br></br>  
   <center><button type="submit" name='log'>Login</button></center>
</form>
<button style="width:40%;float:left;padding:10px;background-color:papayawhip;color: black;"  onclick="document.getElementById('SectionName').style.display='none'" >Cancel</button>
 <span class="psw">Forgot <a href="forgot.php" style="color:red">password?</a></span>
</div>
<script>
var modal = document.getElementById('SectionName');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}</script>
<script>
function openNav() {
  document.getElementById("card1").style.width = "250px";
}

function closeNav() {
  document.getElementById("card1").style.width = "0";
}
</script>
<script>
function myFunction() {
  document.getElementById("SectionName").style.transform = "translateY(225%)";
  document.getElementById("SectionName").style.transition = "transform 2s ease-in-out";
  document.getElementById("SectionName").style.overflow = "hidden";
}
</script>
</body>
</html>