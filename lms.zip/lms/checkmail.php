<?php
$otp = rand(100000,999999);
//the subject
$sub = "Leave OTP";
//the message
$msg = "Your OTP is : $otp";
//recipient email here
$rec = "yaswanthsailalam@gmail.com";
//send email
mail($rec,$sub,$msg);
?>