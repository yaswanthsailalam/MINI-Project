<?php
                        $con=mysqli_connect('localhost','root',"","library");
                        if(!$con)
                        {
                          echo "db not connected";
                        }
                        $s="select * from login where Status='No'";  
                        $query=mysqli_query($con,$s);
                        while($row=mysqli_fetch_assoc($query))
                        {
                        ?>
                          <div class="card3">
                            <div class="card1">
                            <br>
                            <span>
                              <?php echo $row['Name']?>
                            </span>
                            <br>
                            <label>Employee</label>
                            <p>
                            <?php echo $row['emp']?>
                            </p>
                            <br>
                            <label>Name</label>
                            <p>
                            <?php echo $row['name']?>
                            </p>
                            </div>
                            <div class="card2">
                            <form action="request.php" method="post">
                              <button name='app' type="submit" value="<?php echo $row['Regno']?>"><p>Grant Leave</p></button>
                              <button name='dis' type="submit" value="<?php echo $row['Regno']?>"><p>Reject<p></button>
                            </form>
                            </div>
                          </div>
    
                        <?php
                        }
                    ?>
                     <?php

                        if(isset($_POST['app']))
                        {
                            $query=$_POST['app'];
                            $s="update login set Status='YES' where Regno='$query'";
                            $res=mysqli_query($con,$s);
                            echo '<script>window.location.href="request.php"</script>';
                        }
                        if(isset($_POST['dis']))
                        {
                            $query=$_POST['dis'];
                            $s="update login set Status='disapproved' where Regno='$query'";
                            $res=mysqli_query($con,$s);
                            echo '<script>window.location.href="request.php"</script>';
                        }
                        ?>