<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <title>Document</title>
  <style>
body {
  margin:0;
  font-family:cursive;
}

.menu {
  overflow: hidden;
  background-color: #333;
  margin:0;
}

.menu a {
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.menu .icon {
  display: none;
}

a:hover{
  opacity:0.7;
  transition: (1.1);
  background-color:white;
  color:black;
}


}
.header{
  width:100%;
  font-family:cursive;
  font-size:20px;
  margin: 0;
  text-align:center;
  color:black;
}
.bg{
  background-image: url('background1.png');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
}

.head{
  text-align: center;
  color:white;

}

button {
  background-color:#333;
  color: white;
  cursor: pointer;
  width: 100px;
  display:inline-block;
  text-align:center;
}

button:hover {
  opacity: 0.7;
  transition: (1.1);
}





.hod{
position:absolute;
display:block;
}
table,th,td{
border:1px solid black;
}

.table{
  width:90%;
  margin: 10px 0 0 30px;
}

.group:after {
  content: "";
  display: block;
  clear: both;
}
</style>
</head>
<body>
  <form action="confirmform.php" method="get">
  <input type="date" name="from"/>
  <input type="date" name="to"/>
  <input type="submit" name='submit'>
  </form>
 

					<div style="text-align: center; padding-top: 2em; border-top: 1px solid rgb(153, 202, 129); margin-top: 1em;">
					<table class="table">
                          <tr>
                              <th>FromId</th>
                              <th>ToId</th>
                              <th>Section</th>
                              <th>Period</th>
                              <th>DAY</th>
                              <th>Date</th>
                              <th>status</th>
                          </tr>
                        
<?php
$con=mysqli_connect('localhost','root',"","lms");
                        if(!$con)
                        {
                          echo "db not connected";
                        }
                        if(isset($_GET['submit']))
                        {
                          
                          $date1=$_GET['from'];
                          $date2=$_GET['to'];
                          for($daa=$date1;$daa<=$date2;$daa++)
                          {
                        $s="select * from requesttable where FromId='$_SESSION[name]' and Date='$daa'";						
                        $query=mysqli_query($con,$s);
                        while($row=mysqli_fetch_assoc($query))
                        {
                        ?>
						

                           <tr>
                               <td><?php echo $row['FromId']?></td>
                               <td><?php echo $row['ToId']?></td>
                               <td><?php echo $row['Section']?></td>
                               <td><?php echo $row['Period']?></td>
                               <td><?php echo $row['Day']?></td>
                               <td><?php echo $row['Date']?></td>
                               <td> <form action="confirmform.php" method="post">
                              <center><button name='app' type="submit" id="<?php echo $row['RequestId']?>" value="<?php echo $row['RequestId']?>"><p>Grant</p></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              </button></center>
                            </form></td>

                           </tr>
                        
						  
                        <?php
                        }
                      }
                        echo "</table>";
                      }
?>

						  <input type="submit" value="Request My Appointment" class="wpcf7-form-control wpcf7-submit">
						  <img class="ajax-loader" src="http://www.professionalaudiologicalservices.com/wp-content/plugins/contact-form-7/images/ajax-loader.gif" alt="Sending ..." style="visibility: hidden;">
						  </div>
						  <div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div></div>
<?php
if(isset($_POST['app']))
{
  $v=$_POST['app'];
  echo "hii";
  if($v=='clicked')
  {
    echo "<script>alert('already clicked')</script>";
    header("Location: " . $_SERVER["HTTP_REFERER"]);

  }
  $s="select * from requesttable where RequestId=$v";
  $q=mysqli_query($con,$s);
  $row=mysqli_fetch_assoc($q);
  $s2="select * from signup where FirstName='$row[ToId]'";
  $q2=mysqli_query($con,$s2);
  $row2=mysqli_fetch_assoc($q2);
  $y=$row2['EmailId'];
	
  $sub="E-LEAVE Website";
        $msg="Hello '$row[ToId]' ,
			This is '$_SESSION[name]' ,Thankyou for accepting the request .Please go to '$row[Section]' for period '$row[Period]' on '$row[Date]'";
	
		
        mail($y,$sub,$msg);
  $s1="select * from requesttable where FromId='$row[FromId]' and Period='$row[Period]' and Date='$row[Date]' and RequestId <> $v";
  $q1=mysqli_query($con,$s1);
  echo $s1;
    echo "<br>";
  while($row1=mysqli_fetch_assoc($q1))
  {
    print_r($row1);
    echo "<br>";
    $s2="select * from signup where FirstName='$row1[ToId]'";
    echo $s2;
    echo "<br>";
  $q2=mysqli_query($con,$s2);
  $row2=mysqli_fetch_assoc($q2);
  $y=$row2['EmailId'];
	
  $sub="E-LEAVE Website";
        $msg="Hello '$row1[ToId]' ,
			This is '$_SESSION[name]' ,Thankyou for accepting the request. I have adjusted  another person for '$row1[Section]' for period '$row1[Period]' on '$row1[Date]' ";
	
		
        mail($y,$sub,$msg);
        $s4="delete from requesttable where RequestId=$row1[RequestId]";
        $q=mysqli_query($con,$s4);
  }
  echo "<script>Document.getElementById('$v')='clicked'</script>";
header("Location: " . $_SERVER["HTTP_REFERER"]);
  
}
if(isset($_POST['submit1']))
{
  $y='lyaswanthsai.18.cse@anits.edu.in';
	$k=$_SESSION['name'];
  $s1="select * from leavetable where Name='$k'";
  $q=mysqli_query($con,$s1);
  $row=mysqli_fetch_assoc($q);
  $sub="E-LEAVE Website";
        $msg="Hello HOD maam ,
			This is '$_SESSION[name]' , applied for a leave from '$row[From]' to '$row[To]' please log on to know more details ";
	
		
        mail($y,$sub,$msg);
      echo "<script>window.location.href='facultyform.php'</script>";
}
?>
 <form action="confirmform.php" method="post"> 
  <input type="submit" name='submit1'>
  </form>
</body>

</html>