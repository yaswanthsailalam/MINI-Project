<?php
       if(isset($_POST['submit']))
       {
		    session_start();
			$connect = mysqli_connect("localhost","root","","lms");
			if(!$connect)
			{
				echo "failed";
			}
			$userid = $_POST['empid'];
			$Email = $_POST['email'];
			$_SESSION['Email'] = $Email;
			$s="select * from `signup` where `EmployeeId`='$userid' and `EmailId` = '$Email'";
			$result=mysqli_query($connect,$s);
			$row=mysqli_num_rows($result);
			if($row==1)
			{
				$ch=mysqli_fetch_assoc($result);
				$otp=rand(100000,999999);
				session_start();
				$_SESSION["otp"] = $otp;
				$sub="otp to reset your password";
				$msg="your otp is :$otp";
				mail($Email,$sub,$msg);
				header("LOCATION:otp.php");
			}  
			else
			{
				echo "<script>alert('Invalid Details');</script>";
			}
        }
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {font-family: cursive;}
form {border: 3px solid #f1f1f1;
 opacity:0.8;
 }

input[type=email], input[type=otp] ,input[type=userid]{
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
.formstyle{
  width: 40%;
  height: 50%;
  text-align: left;
  background-color: white;
  bottom:300px;


}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
.container {
  padding: 10px;
}

span.psw {
  float: right;
  padding-top: 16px;
}
.head{
  text-align: center;
  color:black;
}
.bg{
  background-image: url('background1.png');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
  }
</style>
</head>
<body class="bg">
<div style = "position:fixed; left:30%; top:100px; background-color:white;text-align: left;width:40%;height:80%">

<form action="forgot.php" method="POST">
  <div class="head">
    <h1> Forgot Password</h1>
  </div>
  <div class="container">
    <label for="empid"><b>USER ID</b></label>
    <input type="empid" placeholder="Enter UserName" name="empid" required>
    <label for="email"><b>User valid Email</b></label>
    <input type="email" placeholder="Enter Email" name="email">
    <button  type="submit" name="submit">Receive OTP</button>
   
  </div>
  </div>
</form>


</div>
</center>

</body>
</html>