
<?php
  session_start();
  $con=mysqli_connect("localhost","root","","lms");
    if(!$con)
    {
        echo "db not connected";
  }
?>
<!DOCTYPE html>
<html>
<head>
    <title>ADMIN PAGE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
  <style>
    @import url('https://fonts.googleapis.com/css?family=Alegreya+Sans:800');

    body{
      font-family: 'Alegreya Sans', sans-serif;
      overflow-x: hidden;
      background-color: #ffffcc;
    }
    .header{
  font-size:30px;
  text-align:center;
  color:black;
  float: left;
  display: inline-block;
  font-family:'Alegreya Sans', sans-serif;
  margin-left: 20%;
}
 .header h1{
  font-size: 2em;
  font-weight: 900;
  color:red;
}
h1 span{
  color:navy;
}
    .nav{
      height: 100%;
      width: 0;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #111;
      opacity: .9;
      overflow-y: hidden;
      padding-top: 60px;
      transition: 0.7s;
    }
    .nav a {
      display: block;
      padding: 20px 30px 20px;
      font-size: 25px;
      text-decoration: none;
      color: #ccc;
    }
    .nav a:hover{
      color:#fff;
      transition: : 0.4s;
      opacity:0.7;
    }
    .nav .close{
      position: absolute;
      top: 0;
      right: 22px;
      margin-left: 50px;
      font-size: 30px;
    }
    .slide a{
      color: #000;
      font-size: 30px;
      float: right;
    }
    #content{
      padding: 20px;
      transition: margin-left 0.7s;
    }
    h2 {
      animation: color-change 1s infinite;
      font-style:italic;
    }

    @keyframes color-change {
      0% { color: #eb0000; }
      50% { color:  #D22B2B; }
      100% { color: #8B0000; }
    }

    .cards
    {   
      display: block;
      width:60%;
      height:200px;
      margin-top: 15%;
      margin-left:20%;
    }
    .leftt{
      width:45%;
       background-color:white;
      display: inline-block;
      height: 220px;
      float: left;
      border-radius: 25px;
      box-shadow:1px 15px 10px 1px black;
    }
    .rightt{
      width: 45%;
      display: inline-block;
      background-color:white;
      height: 220px;
      float: right;
      border-radius: 25px;
      box-shadow:1px 15px 10px 1px black;
    }
    .rightt img,.leftt img{
      width:180px;
      height: 140px;
      margin-left:20%;
    }
    .rightt:hover,.leftt:hover{
      background-color:#cce6ff;
      color: white;
      transition: : 1s;
    }
    .profile{
   width:55%;
    height:380px;
    border-radius: 25px;
    background-color: white;
      color:black;
      margin-left:26%;
      margin-top:10%;
      box-shadow:0px 10px 10px 0px black;
      display:none;
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  overflow: auto; /* Enable scroll if needed */
  padding-top: 60px;
  font-family:sans-serif;
  }
  .profile label{
    color:red;
    font-size:20px;
    margin-left:5%;

  }
  .profile p{
      margin-left:5%;
      color:navy;
      font-size: 15px;
      width:85%;
      background-color:#f2f2f2;
      padding:5px;
      border-radius:20px;
  }
  .left{
    margin-top:0;
    width:50%;
    height:78%;
    display: inline-block;
    float:left;
  }
  .right{
    width:50%;
    height:78%;
    margin-top:0;
    float:right;
    display:inline-block;
    
  }
.profile button {
  display: inline-block;
  padding: 13px;
  color: white;
  font-size:15px;
  background-color:navy;
  text-align: center;
  width:80px;
  float:right;
  margin:0 15px 0px;
  border-radius:10px;
}
  .pro{
    width:55%;
    height:380px;
    border-radius: 25px;
    background-color: white;
      color:black;
      margin-left:26%;
      margin-top:10%;
      box-shadow:0px 10px 10px 0px black;
      display:none;
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  overflow: auto; /* Enable scroll if needed */
  padding-top: 60px;
  font-family:sans-serif;
  }
  .pro label{
    color:red;
    font-size:20px;
    margin-left:5%;

  }
  .pro input{
      margin-left:5%;
      color: navy;
      font-size: 18px;
      width:85%;
      background-color:#f2f2f2;
      padding:5px;
      border-radius: 10px;
  }
.pro button {
   display: inline-block;
  padding: 13px;
  color: white;
  font-size:15px;
  background-color:navy;
  text-align: center;
  width:80px;
  float:right;
  margin:0 15px 0px;
  border-radius:10px;
}
  </style>
</head>
<body>
  <div class="rks">
    <script>
      function openSlideMenu()
      {
        document.getElementById('menu').style.width = '250px';
        document.getElementById('content').style.marginLeft = '100px';
      }
      function closeSlideMenu()
      {
        document.getElementById('menu').style.width = '0';
        document.getElementById('content').style.marginLeft = '0';
      }
    </script>
    
    <div id="content">
            
      <span class="slide">
        <a href="#" onclick="openSlideMenu()">
          <i class="fas fa-bars"></i>
        </a>
      </span>
      <div class="header">
                    <h1><span>ANITS</span> E-Leave <span> Management</span></h1>
          </div>
          <h5 style="float:left; color:black; font-size:20px; top:70px;margin-right:60px;position:relative;"><b>WELCOME <?php echo $_SESSION['name']; ?></b></h5>
             <div class="cards">
              <div class="leftt">
              <img src="leaveicon.png">
                <h2 style="margin-left:20%;"> <button onclick="location.replace('teacherinputs.php')" type="submit">Apply for LEAVE</button></h2>
              </div>
              <div class="rightt">
                <img src="requesticon.png">
                <h2 style="margin-left:20%;"> <a href="facultyrequestform.php">View Requests</a></h2>
              </div>
             </div>
      <div id="menu" class="nav">
        <a href="#" class="close" onclick="closeSlideMenu()">
          <i class="fas fa-times"></i>
        </a>
          <a href="confirmform.php">Confirm</a>
         <a href="#" onclick="document.getElementById('id01').style.display='block'" onclick="myFunction()" style="width:auto;">Profile</a>
        <a href="#" data-toggle="modal" data-target="#logoutModal"><i class="fas fa-sign-out-alt"></i>Logout</a> 
      </div>
      <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
              </div>
              <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
              <button class="btn btn-warning" type="button" data-dismiss="modal">Cancel</button>
              <form action="logout.php" method="POST"> 
              <button type="submit" name="logout_btn" class="btn btn-primary">Logout</button>
              </form>
            </div>
              </div>
            </div>
  </div>
  <div class="profile" id="id01">
                     <?php
                        $a=$_SESSION['empid'];
                        $s="select * from signup where EmployeeId='$a'";  
						
                        $query=mysqli_query($con,$s);
                        $row=mysqli_fetch_assoc($query)
                        
                        ?>
                        <div class="left">
                               <label>Name</label>
                                 <p><?php echo $row['FirstName']?></p>  
                               <label>Phone number2</label>
                                 <p><?php echo $row['MobileNumber2']?></p>
                                     <label>Employee ID</label>
                                 <p> <?php echo $row['EmployeeId']?></p>
                         </div>
                         <div class="right">
                           <label>Phone number</label>
                                  <p> <?php echo $row['MobileNumber']?></p>
                                 <label>Email</label>
                                  <p><?php echo $row['EmailId']?></p>
                               <label>User Type</label>
                                <p><?php echo $row['UserType']?></p>
                        </div>
                           <a  href="#" onclick="document.getElementById('id02').style.display='block'" ><button>Edit</button></a>
                        <button style="float:left;display: inline-block;padding: 13px;color: white;background-color: navy;text-align: center;width:90px;margin:0 0 5px 15px;"  onclick="document.getElementById('id01').style.display='none'" title="Close Modal">Cancel</button>
              
                        <?php
                        
                    ?>
</div>



<div class="pro" id="id02">
                    <form method="POST" action="edit profile.php">
                        <div class="left">
                               <label>Name</label>
                               <br></br>
                                  <input type="text" placeholder="Name" value="<?php echo $row['FirstName']?>" id="Name" name="Name">
                                  <br></br>
                               <label>Phone number2</label>
                               <br></br>
                               <input type="text"  placeholder="Enter alternate mobile number" value="<?php echo $row['MobileNumber2']?>" id="num2" name="MobileNumber2" pattern="[6-9]{1}[0-9]{9}">
                               <br></br>
                         </div>
                         <div class="right">
                           <label>Phone number</label>
                           <br></br>
                                 <input type="text"  placeholder="Enter mobile number" id="num" value="<?php echo $row['MobileNumber']?>" name="MobileNumber" pattern="[6-9]{1}[0-9]{9}">
                                 <br></br>
                                 <label>Email</label>
                                 <br></br>
                                   <input type="email" placeholder="Enter your email" id="email2" name="email2" value="<?php echo $row['EmailId']?>" pattern="^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\.)?[a-zA-Z]+\.)?(anits)\.edu\.in$">
                                   <br></br>
                          </div>
                           <button type="submit" name="submit">Save</button>
                      </form>
                         
                       <button style="float:left;display: inline-block;padding:13px;color: white;background-color:navy;text-align: center;width:100px;"  onclick="document.getElementById('id02').style.display='none'" title="Close Modal">Cancel</button>
        </div>
</div>
<script>
var modal = document.getElementById('id01');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<script>
var modal = document.getElementById('id02');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</body>
</html>