<?php
$con=mysqli_connect('localhost','root','','lms');
if(!$con)
{
    echo "problem in connection";
}
session_start();
$uname=$_POST['Name'];
$pass=$_POST['password'];
$s="select * from signup where LastName='$lname' and Password='$pass'";
   $query=mysqli_query($con,$s);
   $query=mysqli_fetch_assoc($query);
	echo 'Invaid EmailId Or Password';
?>