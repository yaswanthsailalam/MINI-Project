<?php
session_start();
$con = mysqli_connect("localhost","root","","lms");
if(!$con)
{
  echo "failed";
}
	 echo "<form action='condition.php' method='post'>";
	 echo "<center><h1><b>Faculty Adjustment</b></h1></center>";
	 echo "<center><table style='background-color:#F4F6F6 ;border:solid 2px black;border-radius:12px; border:0.5rem solid #616A6B; '; border=2px width=95%></center>
     <tr style='color:black;background-color:#CCD1D1 '>
     <th>Day</th>
     <th>Periods to be replaced</th>
     <th>Check Box</th>
     </tr>
     ";
     mysqli_select_db($con, 'lms');  // selecting database//
     $empid  =   $_SESSION['EmployeeId'];
     $name   =   $_SESSION['Name'];
     $date   =   $_SESSION['From'];
	 $dat   =   $_SESSION['To'];
     $hod        ='pending';
     $principal  ='pending';
     $s="select * from signup where EmployeeId='$empid'";  
     $query=mysqli_query($con,$s);
     $row=mysqli_fetch_assoc($query);
     $mno     = $row['MobileNumber'];
     $emailid = $row['EmailId'];   
$k = "INSERT INTO leavetable VALUES('$empid','$name','$emailid','$mno','$date','$dat','$hod','$principal')";
$ab = "SELECT * FROM timetable WHERE EmployeeId='$empid'";
$abc = mysqli_query($con,$ab);
$abc = mysqli_fetch_assoc($abc);
$ref = $abc['tt'];
    $ref=explode('|',$ref);
            
    for($i=0;$i<6;$i++)
    {
        $ref[$i]=explode(",",$ref[$i]);
    }
	

		for ($da=$date;$da<=$dat;$da++)
		{
			$ti=strtotime($da);
			$day = date('D',$ti);
			$day1 = $day;
			
			echo "<tr style='border:solid 10px black' >
            <td rowspan=8>".$day1."</td>";
            
			if($day=='Mon')
			{
				$day = 0;
			}
			else if($day=='Tue')
			{
				$day = 1;
			}
			else if($day=='Wed')
			{
				$day = 2;
			}
			else if($day=='Thu')
			{
				$day = 3;
			}
			else if($day=='Fri')
			{
				$day = 4;
			}
			else if($day=='Sat')
			{
				$day = 5;
			}
			else if($day=='Sun')
			{
				$day = 6;
			}
			if($day==6)
			{
				
				echo "</tr>";
				continue;
			}
			for($p=0;$p<8;$p++)
			{
				if($ref[$day][$p]=='nop')
				{
					echo "<td >".$p."</td><td >Free Period</td></tr>";
					continue;
				}					
				
				echo "<td>".$p."</td>"."<td><table><tr style='border:solid 10px black'>";
				
				$s = "select * from timetable where EmployeeId<>'$empid'"; 
				$query=mysqli_query($con,$s);
				while($row=mysqli_fetch_assoc($query))
				{
					$a=$row['tt'];
					$t=explode('|',$a);
					if (count($t) == 1)
					{
							echo('<script>alert($row["Id"])</script>');
							
							continue;
					}
					for($i=0;$i<6;$i++)
					{
						
						$t[$i]=explode(",",$t[$i]);
						
					}
				
					if($ref[$day][$p]!='nop')
					{
					$x=$t[$day];
						if($x[$p]=='nop')
						{
							$sec1=explode('|',$row['Section']);
							$flag=0;
							$mat=substr($ref[$day][$p],-2);
								for($var1=0;$var1<count($sec1);$var1++)
								{
									if($mat==$sec1[$var1])
									$flag=1;
								}
							
							if($flag==1)
							{
								echo "<td><b style='color:green';>".$row['EmployeeId']."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$row['FacultyName']."</b></td><td> <input value='$p $row[EmployeeId] $day $mat $da' name='check[]' type='checkbox' checked> </td></tr>";
							}
							else
							{
							echo "<td><b style='color:#2C159B';>".$row['EmployeeId']."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" .$row['FacultyName']."</b></td><td> <input value='$p $row[EmployeeId] $day $mat $da' name='check[]' type='checkbox'> </td></tr>";
							}
						}       
					}
				}
				echo "</table></td>";
				echo "</tr>";
			}
			echo "</div>";
        }
        echo "</table>";
		echo "<br>";
		echo '<button  type="submit" name="submit" class="sub">SUBMIT</button>';
		echo "</form>";
?>
<!DOCTYPE html>
<html>
<head>
<style>
.sub{
	background-color:#5D6D7E;
	border:none;
	color:white;
	padding:15px 32px;
	text-align:center;
	font-size:16px;
}
</style>
</head>
<body>
	
</body>
</html>