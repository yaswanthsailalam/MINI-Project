<?php
	session_start();
	$con=mysqli_connect('localhost','root','','lms');
	if(!$con)
	{
		echo "problem in connection";
	}
	
?>