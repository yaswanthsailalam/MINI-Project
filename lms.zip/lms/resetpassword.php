<?php
session_start();
$con=mysqli_connect('localhost','root','','lms');
if(!$con)
{
    echo "problem in connection";
}
if(isset($_POST['sai']))
	{
		$Email=$_SESSION['Email'];
		$pass=$_POST['Password'];
		$npass = $_POST['ConfirmPassword'];
		$s="update signup set Password='$pass',ConfirmPassword='$npass' where EmailId='$Email'";
		echo "Password Updated Succesfully";
		header("location:leavehome.php");
		$query=mysqli_query($con,$s);
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {font-family:cursive;}
form {border: 3px solid #f1f1f1;
opacity: 0.8;
}

input[type=text], input[type=OTP] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
.formstyle{
  width: 40%;
  height: 50%;
  text-align: left;
  background-color: white;
  bottom:300px;


}
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
.container {
  padding: 10px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
.head{
  text-align: center;
  color:black;
}
.bg{
  background-image: url('background1.png');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
  }
</style>
</head>
<body class="bg">
  <center>
<div style = "position:fixed; left:30%; top:100px; background-color:white;text-align: left;width:40%;height:70%">

<form action="resetpassword.php" method="post">
   <div class="head">
    <h1>Update Password</h1>
  </div>
  <div class="container">
    <label for="password"><b>NEW PASSWORD</b></label>
    <input type="password" placeholder="Enter new password" name="Password" required>

    <label for="password"><b>CONFIRM PASSWORD</b></label>
    <input type="password" placeholder="Confirm Password" name="ConfirmPassword" required>
        
    <button type="submit" name="sai">UPDATE</button> 

  </div>
</form>

</div>
</center>

</body>
</html>