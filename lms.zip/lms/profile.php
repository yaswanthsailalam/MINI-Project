<?php
  SESSION_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body {
  margin:0;
  font-family:cursive;
}
	.profile{
		width:50%;
		height:400px;
	    background-color: #474e5d;
	    color:white;
	    margin-left:24%;
	    margin-top:5%;
	    box-shadow:0px 10px 10px 0px black;

	}
	label{
		color:white;
		font-size:25px;
		margin-left:5%;

	}
	p{
	    margin-left:5%;
	    color: black;
	    font-size: 18px;
	    width:85%;
	    background-color:#f2f2f2;
	    padding:5px;
	}
	.left{
		margin-top:5%;
		width:50%;
		height:78%;
		display: inline-block;
		float:left;
	}
	.right{
		width:50%;
		height:78%;
		margin-top:5%;
		float:right;
		display:inline-block;
		
	}
button {
  display: inline-block;
  padding: 15px;
  color: white;
  font-size:15px;
  background-color: #4d4d4d;
  text-align: center;
  width:100px;
  float:right;
  margin:0 15px 0px;
}
	</style>
</head>
<body>
<div class="profile">
                     <?php
                        $con=mysqli_connect('localhost','root',"","lms");
                        if(!$con)
                        {
                          echo "db not connected";
                        }
                        $s="select * from signup where EmployeeId='ANIL0422'";
                        $query=mysqli_query($con,$s);
                        while($row=mysqli_fetch_assoc($query))
                        {
                        ?>
                        <div class="left">
                               <label>Name</label>
                               	 <p><?php echo $row['FirstName']?></p>  
                               <label>Phone number2</label>
                                 <p><?php echo $row['MobileNumber2']?></p>
                                     <label>Employee ID</label>
                                 <p> <?php echo $row['EmployeeId']?></p>
                         </div>
                         <div class="right">
                         	 <label>Phone number</label>
                                  <p> <?php echo $row['MobileNumber']?></p>
                                 <label>Email</label>
                                  <p><?php echo $row['EmailId']?></p>
                               <label>User Type</label>
                                <p><?php echo $row['UserType']?></p>
                        </div>
                        	 <a  href="edit profile.php"><button>Edit</button></a>
                        <button style="float:left;display: inline-block;padding: 15px;color: white;background-color: #4d4d4d;text-align: center;width:100px;margin:0 0 5px 15px;">Cancel</button>
						  
                        <?php
                        }
                    ?>
</div>
</body>
</html>