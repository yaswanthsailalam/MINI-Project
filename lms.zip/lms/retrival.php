<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "lms");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
<td><?php echo $row1['From']?></td>
<td><?php echo $row1['To']?></td>
<td> </td>
// Attempt select query execution
$sql = "SELECT * FROM 3_4_c";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
			echo "<table>";
				echo "<tr>";
					echo "<th>Day</th>";
					echo "<th>8_40__9_30</th>";
					echo "<th>9_30__10_20</th>";
					echo "<th>9_30__10_20</th>";
					echo "<th>10_20__11_10</th>";
					echo "<th>11_10__12_00</th>";
					echo "<th>12_00__12_50</th>";
					echo "<th>12_50__1_40</th>";
					echo "<th>1_40__2_30</th>";
					echo "<th>2_30__3_20</th>";
				echo "</tr>";
			while($row = mysqli_fetch_array($result)){
				echo "<tr>";
					echo "<td>" . $row['Day'] . "</td>";
					echo "<td>" . $row['8_40__9_30'] . "</td>";
					echo "<td>" . $row['9_30__10_20'] . "</td>";
					echo "<td>" . $row['10_20__11_10'] . "</td>";
					echo "<td>" . $row['11_10__12_00'] . "</td>";
					echo "<td>" . $row['12_00__12_50'] . "</td>"; 
					echo "<td>" . $row['12_50__1_40'] . "</td>";
					echo "<td>" . $row['1_40__2_30'] . "</td>";
					echo "<td>" . $row['2_30__3_20'] . "</td>";
				echo "</tr>";
			}
			echo "</table>";
			
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>