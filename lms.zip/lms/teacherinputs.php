<?php
	SESSION_start();
	$connect = mysqli_connect("localhost","root","","lms");
	if(!$connect)
	{
		echo "failed";
	}
    if(isset($_POST['submit']))
    {
		$Name   	  = 	$_SESSION['name'];
		$_SESSION['Name'] = $Name;
		$EmployeeId   = 	$_SESSION['empid'];
		$_SESSION['EmployeeId'] = $EmployeeId;	
		$From    = 	$_POST['From'];
		$_SESSION['From'] = $From;
		$To   = 	$_POST['To'];
		$_SESSION['To'] = $To;
		$desc=$_POST['desc'];
		
		$HODStatus = "pending";
		$_SESSION['HODStatus'] = $HODStatus;
		$PrincipleStatus = "pending";
		$_SESSION['PrincipleStatus'] = $PrincipleStatus;	
		$s ="INSERT INTO `leavetable`(`Name`, `EmployeeId`, `From`, `To`, `Description`, `HODStatus`, `PrincipleStatus`) VALUES('$Name','$EmployeeId','$From','$To','$desc','$HODStatus','$PrincipleStatus')";
		$result = mysqli_query($connect,$s);
		echo $s;
		echo "Successfully Submitted.... Wait for Permission";
		echo "<script>window.location.href='timetable.php'</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="css/normalize.css">
        <link href='https://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
<style type="text/css">
	*, *:before, *:after {
	  -moz-box-sizing: border-box;
	  -webkit-box-sizing: border-box;
	  box-sizing: border-box;
	}

	body {
	  font-family: 'Nunito', sans-serif;
	  color: #384047;
	}

	.form {
	  max-width:50%;
	  margin: 10px auto;
	  padding: 3px 20px;
	  background: #f4f7f8;
	  border-radius: 8px;
	}

	h1 {
	  margin: 0 0 30px 0;
	  text-align: center;
	}

	input[type="text"],
	input[type="number"],
	textarea,
	input[type="date"],
	select {
	  background: rgba(255,255,255,0.1);
	  border: none;
	  font-size: 16px;
	  height: auto;
	  margin: 0;
	  outline: 0;
	  padding: 10px;
	  width: 100%;
	  background-color:#d9d9d9;
	  color: black;
	  box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
	  margin-bottom: 30px;
	  border-radius:10px;
	}

	select {
	  padding: 6px;
	  height: 32px;
	  border-radius: 10px;
	}

	button {
	  padding: 10px 39px 18px 39px;
	  color:#FFF;
	  background-color:green;
	  font-size: 18px;
	  text-align: center;
	  font-style: normal;
	  border-radius: 15px;
	  width: auto;
	  border: 1px solid #cce6ff;
	  border-width: 1px 1px 3px;
	  box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
	}
button:hover{
	opacity: 0.7;
	background-color: red;
	color: black;
}
label {
  display: block;
  margin-bottom: 8px;
  font-size:20px;
  color: navy;
}

label.light {
  font-weight: 300;
  display: inline;
}

.bg{
  background-image: url('background1.png');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
</head>
    <body class="bg">
<div class="form">
    <form action="teacherinputs.php" onsubmit="return validate();" method="POST">
        <h1>Teacher's Details</h1>
          <label for="name">Name</label>
          <input type="text" id="name" name="Name" value="<?php echo $_SESSION['name']; ?>" disabled>
           <label for="empid">Teacher's id:</label>
          <input type="text" id="empid" name="EmployeeId" value="<?php echo $_SESSION['empid']; ?>" disabled>
		   <label for ="date">From Date</label>
		   <input type="date" id="Date" name="From">
		   <br><br>
		   <label for ="date">To Date</label>
		   <input type="date" id="Date" name="To">
		   <br><br>
		   <label for="desc">Description for Leave</label>
		   <textarea type="text" rows = "5" cols = "20" maxlength = "200" id="desc" name="desc"></textarea>
		   <center><button type="submit" name="submit" style="float:right">APPLY</button></center>
    </form>
    <button style="margin-left:5%;" type="submit" onclick="window.location.href='facultyform.php'">BACK</button>
</div>
    </body>
</html>