<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin:0;
  font-family:cursive;
}

.menu {
  overflow: hidden;
  background-color: #333;
  margin:0;
}

.menu a {
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.menu .icon {
  display: none;
}

a:hover{
  opacity:0.7;
  transition: (1.1);
  background-color:white;
  color:black;
}


}
.header{
  width:100%;
  font-family:cursive;
  font-size:20px;
  margin: 0;
  text-align:center;
  color:black;
}
.bg{
  background-image: url('background1.png');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
}

.head{
  text-align: center;
  color:white;

}

button {
  background-color:#333;
  color: white;
  cursor: pointer;
  width: 100px;
  display:inline-block;
  text-align:center;
}

button:hover {
  opacity: 0.7;
  transition: (1.1);
}





.hod{
position:absolute;
display:block;
}
table,th,td{
border:1px solid black;
}

.table{
  width:90%;
  margin: 10px 0 0 30px;
}
</style>
</head>
<body class="bg">
<div class="header">
  <h1><center>Anits E-Leave Management</center></h1>
 
</div>
<div class="hod">
<h5 style="float:left; color:white; font-size:20px; top:-15px; position:relative;"><b>WELCOME HOD Mam</b></h5>
</div>
<div class="menu" id="myTopnav">
   
  <a href="#contact">Logout</a> 
  <a href="signinform1.html">View Profile</a>
  <a href="#home">Home</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>

<div class="hodbuttons">
<?php
                        $con=mysqli_connect('localhost','root',"","lms");
                        if(!$con)
                        {
                          echo "db not connected";
                        }
                        $s="select * from requesttable where ToId='empid' and status = 'pending'";  
                        $query=mysqli_query($con,$s);
                        while($row=mysqli_fetch_assoc($query))
                        {
                        ?>
                        <table class="table">
                          <tr>
                              <th>NAME</th>
                              <th>EmployeeId</th>
                              <th>Email</th>
                              <th>Phone number</th>
                              <th>DAY</th>
                              <th>Date</th>
                              <th>status</th>
                          </tr>
                           <tr>
                               <td><?php echo $row['Name']?></td>
                               <td><?php echo $row['EmployeeId']?></td>
                               <td><?php echo $row['Email']?></td>
                               <td><?php echo $row['PhoneNumber']?></td>
                               <td><?php echo $row['Day']?></td>
                               <td><?php echo $row['Date']?></td>
                               <td> <form action="requesttable.php" method="post">
                              <center><button name='app' type="submit" value="<?php echo $row['requestid']?>"><p>Grant</p></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              <button name='dis' type="submit" value="<?php echo $row['RequestId']?>"><p>Reject</p></button></center>
                            </form></td>

                           </tr>
                        </table>
						  
                        <?php
                        }
                    ?>
                     <?php

                        if(isset($_POST['app']))
                        {
							
                            $query=$_POST['app'];
                            $s="update requesttable set Status='Approved' where RequestId = $query";
                            $res=mysqli_query($con,$s);
                            
                        }
                        if(isset($_POST['dis']))
                        {
                            $query=$_POST['dis'];
                            $s="update leavetable set HODStatus='disapproved' where RequestId='$query'";
                            $res=mysqli_query($con,$s);
                            echo '<script>window.location.href="hodform.php"</script>';
                        }
                        ?>
  
</div>
</body>
</html>

