-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2021 at 01:04 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `leavetable`
--

CREATE TABLE `leavetable` (
  `Name` varchar(30) NOT NULL,
  `EmployeeId` varchar(10) NOT NULL,
  `From` date NOT NULL,
  `To` date NOT NULL,
  `Description` text NOT NULL,
  `HODStatus` varchar(10) NOT NULL,
  `PrincipleStatus` varchar(10) NOT NULL,
  `leaveid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leavetable`
--

INSERT INTO `leavetable` (`Name`, `EmployeeId`, `From`, `To`, `Description`, `HODStatus`, `PrincipleStatus`, `leaveid`) VALUES
('G V Gayathri', 'ANIL0100', '2021-07-26', '2021-07-26', 'I want Leave', 'Approved', 'pending', 1),
('Sivaranjani', 'ANIL0378', '2021-07-29', '2021-07-29', 'Leave', 'pending', 'pending', 2),
('Sivaranjani', 'ANIL0378', '2021-07-28', '2021-07-28', 'Leave Apply', 'pending', 'pending', 3);

-- --------------------------------------------------------

--
-- Table structure for table `requesttable`
--

CREATE TABLE `requesttable` (
  `FromId` varchar(100) NOT NULL,
  `FromEmpId` varchar(100) NOT NULL,
  `ToId` varchar(100) NOT NULL,
  `ToEmpId` varchar(100) NOT NULL,
  `Day` int(10) NOT NULL,
  `Date` date NOT NULL,
  `Period` int(20) NOT NULL,
  `Section` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `RequestId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `requesttable`
--

INSERT INTO `requesttable` (`FromId`, `FromEmpId`, `ToId`, `ToEmpId`, `Day`, `Date`, `Period`, `Section`, `Status`, `RequestId`) VALUES
('G V Gayathri', 'ANIL0100', 'Mishra', 'ANIL0123', 0, '2021-07-26', 3, '2B', 'Approved', 1),
('G V Gayathri', 'ANIL0100', 'Priyanka', 'ANIL0422', 0, '2021-07-26', 5, '3C', 'Approved', 5),
('Sivaranjani', 'ANIL0378', 'G V Gayathri', 'ANIL0100', 3, '2021-07-29', 1, 'MT', 'Approved', 8),
('Sivaranjani', 'ANIL0378', 'Priyanka', 'ANIL0422', 2, '2021-07-28', 0, 'MT', 'Approved', 9);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `FirstName` varchar(30) NOT NULL,
  `MobileNumber` bigint(10) NOT NULL,
  `MobileNumber2` bigint(10) NOT NULL,
  `EmailId` varchar(50) NOT NULL,
  `EmployeeId` varchar(10) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `ConfirmPassword` varchar(30) NOT NULL,
  `UserType` varchar(30) NOT NULL,
  `leavestatus` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`FirstName`, `MobileNumber`, `MobileNumber2`, `EmailId`, `EmployeeId`, `Password`, `ConfirmPassword`, `UserType`, `leavestatus`) VALUES
('Deepthi', 9515075264, 0, 'alladaharshini.18.cse@anits.edu.in', 'ANIL0084', 'Deepthi*0084', 'Deepthi*0084', 'FACULTY', 0),
('Jagadish', 9441345914, 0, 'gjagadish.cse@anits.edu.in', 'ANIL0092', 'Jagadish*0092', 'Jagadish*0092', 'FACULTY', 1),
('G V Gayathri', 6303899690, 0, 'ksindhupriya.18.cse@anits.edu.in', 'ANIL0100', 'Gayathri*0100', 'Gayathri*0100', 'FACULTY', 0),
('Bhavani', 9492275216, 9701862361, 'kkarthik.18.cse@anits.edu.in', 'ANIL0108', 'Bhavani*0108', 'Bhavani*0108', 'FACULTY', 1),
('Mishra', 8008523873, 0, 'komminikingson.18.cse@anits.edu.in', 'ANIL0123', 'Mishra*0123', 'Mishra*0123', 'FACULTY', 0),
('Santoshi', 7331175838, 0, 'kvandana.18.cse@anits.edu.in', 'ANIL0146', 'Santoshi*0146', 'Santoshi*0146', 'FACULTY', 0),
('Chandra Sekhar', 9987033774, 0, 'alamuriganeshkumar@gmail.com', 'ANIL0151', 'Surya*0151', 'Surya*0151', 'FACULTY', 0),
('Gowri Pushpa', 9676428405, 0, 'ivarun.18.cse@anits.edu.in', 'ANIL0152', 'Gowripushpa*0152', 'Gowripushpa*0152', 'FACULTY', 0),
('Ratan Kumar', 9989141258, 0, 'gpavankalyan.18.cse@anits.edu.in', 'ANIL0162', 'Ratan*0162', 'Ratan*0162', 'FACULTY', 0),
('Pranitha', 9059049598, 9640674257, 'bsravanya.18.cse@anits.edu.in', 'ANIL0191', 'Pranitha*0191', 'Pranitha*0191', 'FACULTY', 0),
('Suresh', 9515529730, 0, 'pnagajyothi.18.cse@anits.edu.in', 'ANIL0240', 'Suresh*0240', 'Suresh*0240', 'FACULTY', 0),
('Sivaranjani', 9704916139, 0, 'ssravani.18.cse@anits.edu.in', 'ANIL0378', 'Sivaranjani*0378', 'Sivaranjani*0378', 'HOD', 0),
('RamaKrishna Murthy', 7989182076, 0, 'ajaswanth.18.cse@anits.edu.in', 'ANIL0396', 'Murthy*0396', 'Murthy*0396', 'FACULTY', 0),
('Priyanka', 9492276216, 9849107245, 'lyaswanthsai.18.cse@anits.edu.in', 'ANIL0422', 'Priya*0422', 'Priya*0422', 'FACULTY', 0),
('Lokeswari', 9676350107, 0, 'aganeshkumar.18.cse@anits.edu.in', 'ANIL0423', 'Lokeswari*0423', 'Lokeswari*0423', 'FACULTY', 0),
('Krishnanjenyulu', 9398577241, 0, 'ganilkumar.18.cse@anits.edu.in', 'ANIL0531', 'Anil*0531', 'Anil*0531', 'FACULTY', 0),
('Joshua JohnSon', 9515597192, 9492275216, 'ysnnagendra.18.cse@anits.edu.in', 'ANIL0367', 'Joshua*0367', 'Joshua*0367', 'FACULTY', 0),
('Gayathri', 9675597192, 9121658764, 'msumanth.18.cse@anits.edu.in', 'ANIL0307', 'GG*0307', 'GG*0307', 'FACULTY', 0),
('Sathar', 7993600107, 9381285044, 'sumanthmotha125@gmail.com', 'ANIL0455', 'Sathar*0455', 'Sathar*0455', 'FACULTY', 0),
('Amaravathi', 9177582585, 0, 'npavan.18.cse@anits.edu.in', 'ANIL0240', 'Amaravathi*anits', 'Amaravathi*anits', 'FACULTY', 0),
('Lakshmi', 9676528567, 0, 'ksindhupriya.18.cse@antis.edu.in', 'ANIL0170', 'Lakshmi*0170', 'Lakshmi*0170', 'FACULTY', 0);

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `EmployeeId` varchar(50) NOT NULL,
  `tt` varchar(500) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `FacultyName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`EmployeeId`, `tt`, `Section`, `FacultyName`) VALUES
('ANIL0001', 'nop,wt3A,nop,nop,nop,ostlab3A,ostlab3A,ostlab3A|wt3A,nop,nop,nop,nop,selab3B,selab3B,selab3B|nop,nop,wt3A,nop,nop,nop,nop,nop|nop,nop,nop,nop,nop,wt3A,nop,nop|nop,nop,nop,wt3A,nop,ostlab3A,ostlab3A,ostlab3A|nop,selab3B,selab3B,selab3B,nop,nop,nop,nop\r\n', '3A|3B', 'BoseBabu'),
('ANIL0002', 'os2A,nop,nop,nop,nop,oslab2A,oslab2A,oslab2A|nop,nop,os2A,nop,pswithclab1B,pswithclab1B,pswithclab1B,nop|nop,nop,nop,nop,nop,nop,os2A,nop|nop,oslab2A,oslab2A,oslab2A,nop,nop,nop,nop|nop,nop,nop,os2A,nop,selab3A,selab3A,selab3A|os2A,nop,nop,nop,nop,nop,nop,nop', '2A|3A|1B', 'Mamatha'),
('ANIL0003', 'nop,nop,nop,nop,pswithc1AI,mpilab2A,mpilab2A,mpilab2A|pswithc1AI,nop,nop,nop,nop,nop,nop,nop|nop,nop,nop,nop,pswithclab1C,pswithclab1C,pswithclab1C,nop|pswithc1AI,mpilab2A,mpilab2A,mpilab2A,nop,nop,nop,nop|nop,nop,pswithc1AI,nop,pswithclab1AI,pswithclab1AI,pswithclabAI&ML,nop|nop,nop,nop,nop,pswithc1AI,nop,nop,nop\r\n', '1AI|2A|1C', 'Yasaswi'),
('ANIL0004', 'nop,mpilab2C,mpilab2C,mpilab2C,nop,cc4C,cc4C,cc4C|nop,nop,nop,cc4C,nop,nop,cn4C,nop|nop,cn2C,nop,cc4C,nop,nop,nop,nop|cc2C,nop,nop,cn2C,nop,mpilab2C,mpilab2C,mpilab2C|nop,cn2C,nop,nop,nop,nop,nop,nop|nop,nop,nop,cn2C,nop,nop,nop,nop.\r\n', '2C|4C', 'Manoj'),
('ANIL0005', 'nop,flat2B,nop,nop,nop,oslab2A,oslab2A,oslab2A|nop,nop,nop,nop,pswithc1ds,nop,flat2B,nop|nop,flat2B,nop,nop,nop,pswithc1DS,nop,nop|nop,pswithc1DS,nop,nop,pswithclab1DS,pswithclab1DS,pswithclab1DS,nop|nop,pswithc1DS,nop,nop,nop,flat2B,nop,nop|nop,nop,flat2B,nop,nop,pswithc1DS,nop,nop', '1DS|2A|2B', 'P Spandana'),
('ANIL0084', 'projectlab4B,projectlab4B,projectlab4B,nop,nop,nop,nop,aos1MT|projectlab4B,projectlab4B,projectlab4B,nop,nop,AOS1MT,nop,nop|projectlab4B,projectlab4B,projectlab4B,nop,nop,nop,nop,nop|nop,projectlab4B,projectlab4B,projectlab4B,nop,nop,nop,nop|nop,nop,aos1MT,aos1MT,nop,nop,nop,nop|nop,nop,nop,nop,nop,nop,nop,nop', '4B|1MT', 'K S Deepthi'),
('ANIL0092', 'nop,nop,nop,nop,nop,cc4B,cc4B,nop|nop,ca3A,nop,cc4B,nop,nop,nop,nop|nop,ca3A,nop,cc4B,nop,nop,nop,nop|cc4B,nop,ca3A,nop,dswithclab1,dswithclab1,dswithclab1,nop|nop,nop,ca3A,nop,nop,selab3A,selab3A,selab3A|ca3A,nop,nop,nop,nop,nop,nop,nop', '3A|4B|1DS', 'G Jagadish'),
('ANIL0100', 'nop,nop,nop,cg2B,nop,cd3C,nop,nop|cg2B,oslab2B,oslab2B,oslab2B,nop,cd3C,nop,nop|nop,cd3C,nop,cg2B,nop,oslab2B,oslb2B,oslab2B|cg2B,nop,cd3C,nop,nop,nop,nop,nop|nop,nop,cg2B,nop,nop,nop,nop,nop|nop,nop,nop,cd3C,nop,nop,nop,nop', '2B|3C', 'G V Gayathri'),
('ANIL0108', 'nop,pswithc1A,nop,nop,pswithclab1A,pswithclab1A,pswithclab1A,nop|nop,nop,nop,nop,nop,nop,pswithc1A,nop|pswithclabEC1A,pswithclabEC1A,pswithclabEC1A,nop,pswithc1A,nop,nop,nop|pswithc1A,nop,nop,nop,nop,ostlab3C,ostlab3C,ostlab3C|nop,ostlab3C,ostlab3C,ostlab3C,nop,nop,nop,nop|nop,nop,nop,nop,pswithc1A,nop,nop,nop', '1A|3C|1ECA', 'S A Bhavani'),
('ANIL0123', 'nop,nop,cn1MT,nop,nop,nop,cn2B,nop|nop,np_wp1MT,np_wp1MT,np_wp1MT,nop,nop,cn1MT,nop|nop,nop,cn1MT,cn1MT,nop,nop,nop,nop|nop,nop,nop,nop,nop,cn2B,cn2B,nop|cn2B,nop,nop,nop,nop,nop,nop,nop|nop,cn2B,nop,nop,nop,nop,nop,nop', '2B|1MT', 'S R Mishra'),
('ANIL0146', 'nop,cg2A,nop,nop,nop,mpi2B,nop,nop|nop,mpilab2B,mpilab2B,mpilab2B,nop,cg2A,nop,nop|cg2A,nop,mpi2B,nop,nop,mpilab2B,mpilab2B,mpilab2B|nop,mpi2B,nop,nop,nop,nop,nop,nop|nop,cg2A,nop,nop,nop,nop,mpi2B,nop|nop,cg2A,nop,mpi2B,nop,nop,nop,nop', '2A|2B', 'G Santoshi'),
('ANIL0151', 'nop,nop,ads3C,nop,nop,nop,cg2C,nop|cg2C,nop,nop,ads3C,nop,nop,nop,nop|ads3C,nop,nop,nop,nop,nop,cg2C,nop|ads3C,nop,cg2C,nop,nop,selab3C,selab3C,selab3C|nop,selab3C,selab3C,selab3C,nop,cg2C,nop,ads3C|nop,cg2C,nop,nop,nop,nop,nop,nop', '2C|3C', 'K ChandraSkkhar'),
('ANIL0152', 'nop,nop,mpi2A,nop,nop,mpilab2A,mpilab2A,mpilab2A|mpi2A,nop,nop,nop,nop,ostlab3B,ostlab3B,ostlab3B|nop,nop,mpi2A,nop,nop,nop,nop,nop|nop,mpilab2A,mpilab2A,mpilab2A,nop,nop,mpi2A,nop|nop,nop,mpi2A,nop,nop,nop,nop,nop|nop,ostlab3B,ostlab3B,ostlab3B,nop,nop,nop,nop\r\n', '2A|3B', 'G GOwri Pushpa'),
('ANIL0162', 'nop,se3B,nop,nop,nop,es1MT,es1MT,nop|nop,nop,se3B,nop,nop,selab3B,selab3B,selab3B|nop,nop,se3B,nop,nop,nop,nop,nop|es1MT,nop,nop,nop,nop,se3B,nop,nop|se3B,nop,nop,nop,nop,es1MT,nop,nop|nop,selab3B,selab3B,selab3B,nop,nop,nop,nop', '3B|1MT', 'S RatanKumar'),
('ANIL0170', 'nop,nop,se3A,nop,nop,selab3A,selab3A,selab3A|projectlab4B,projectlab4B,projectlab4B,se3A,nop,nop,nop,nop|projectlab4B,projectlab4B,projectlab4B,nop,nop,se3A,nop,nop|se3A,nop,nop,nop,nop,nop,nop,nop|nop,nop,nop,nop,nop,selab3A,selab3A,selab3A|nop,nop,se3A,nop,nop,nop,nop,nop', '3A|4B', 'SVSS Lakshmi'),
('ANIL0191', 'projectlab4A,projectlab4A,projectlab4A,nop,nop,nop,nop,nop|projectlab4A,projectlab4A,projectlab4A,flat2A,nop,nop,nop,nop|projectlab4A,projectlab4A,projectlab4A,flat2A,nop,nop,nop,nop|flat2A,projectlab4A,projectlab4A,projectlab4A,nop,nop,nop,nop|nop,nop,nop,nop,nop,nop,flat2A,nop|nop,nop,flat2A,nop,nop,nop,nop,nop', '2A|4A', 'G Pranitha'),
('ANIL0197', 'projectlab4C,projectlab4C,projectlab4C,cpEE3A,nop,nop,nop,nop|projectlab4C,projectlab4C,projectlab4C,nop,nop,nop,nop,nop|projectlab4C,projectlab4C,projectlab4C,nop,nop,nop,nop,nop|cpEE3A,projectla4C,projectlab4C,projectlab4C,nop,nop,nop,nop|nop,nop,nop,nop,nop,cpEE3A,nop,nop|nop,nop,nop,nop,nop,cpEE3A,cpEE3A,nop', '3A|4C', 'V UshaBala'),
('ANIL0236', 'ca3B,nop,nop,cn3A,nop,ostlab3A,ostlab3A,ostlab3A|nop,cn2A,nop,ca3B,nop,nop,nop,nop|nop,ca3B,nop,nop,nop,cn2A,nop,nop|nop,nop,nop,ca3B,nop,cn2A,nop,nop|cn2A,nop,ca3B,nop,nop,ostlab3A,ostlab3A,ostlab3A|nop,nop,nop,nop,nop,nop,nop,nop', '2A|3A|3B', 'B SivaJyothi'),
('ANIL0240', 'projectlab4A,projectlab4A,projectlab4A,nop,nop,nop,nop,nop|projectlab4A,projectlab4A,projectlab4A,flat2A,nop,nop,nop,nop|projectlab4A,projectlab4A,projectlab4A,flat2A,nop,nop,nop,nop|flat2A,projectlab4A,projectlab4A,projectlab4A,nop,nop,nop,nop|nop,nop,nop,nop,nop,nop,flat2A,nop|nop,nop,flat2A,nop,nop,nop,nop,nop', '2A|4A', 'K Suresh'),
('ANIL0307', 'nop,oslab2C,oslab2C,oslab2C,nop,nop,nop,nop|nop,nop,nop,nop,pswithc1C,nop,nop,nop|nop,nop,nop,nop,problemsolvingwithclab1C,problemsolvingwithclab1C,problemsolvingwithclab1C,nop|nop,pswithc1C,nop,nop,nop,oslab2C,oslab2C,oslab2C|nop,pswithc1C,pswithc1C,nop,pswithclab1AI,pswithclab1AI,pswithclab1AI,nop|pswithc1C,nop,nop,nop,nop,nop,nop,nop', 'AI|2C|1C', 'G Gayathri'),
('ANIL0355', 'nop,oslab2C,oslab2C,oslab2C,nop,os2C,nop,nop|nop,mpilab2B,mpilab2B,mpilab2B,nop,os2C,nop,nop|nop,nop,os2C,nop,nop,mpilab2B,mpilab2B,mpilab2B|os2C,nop,nop,nop,nop,oslab2C,oslab2C,osla2bC|os2C,nop,nop,nop,nop,nop,nop,nop|nop,os2C,nop,nop,nop,nop,nop,nop', '2B|2C', 'T Anitha'),
('ANIL0367', 'nop,nop,os2B,nop,problemsolvingwithclab1C,problemsolvingwithclab1C,problemsolvingwithclab1C,nop|nop,oslab2B,oslab2B,oslab2B,nop,os2B,nop,nop|nop,nop,nop,nop,nop,oslab2B,oslab2B,oslab2B|nop,nop,os2B,nop,clab1D,clab1D,clab1D,nop|nop,os2B,nop,nop,nop,nop,nop,nop|os2B,nop,nop,nop,nop,nop,nop,nop', '2B|1DS', 'S Joshua Johnson'),
('ANIL0378', 'nop,nop,nop,spm1MT,nop,nop,nop,nop|nop,nop,nop,nop,nop,nop,nop,nop|spm1MT,nop,nop,nop,nop,nop,nop,nop|nop,spm1MT,nop,nop,nop,nop,nop,nop|nop,nop,nop,nop,nop,nop,nop,nop|nop,nop,nop,nop,nop,nop,nop,nop', '1MT', 'Dr SivaRanjani'),
('ANIL0396', 'nop,nop,nop,nop,nop,cc4A,cc4A,nop|adbms1MT,nop,nop,cc4A,nop,nop,nop,nop|nop,nop,nop,cc4A,nop,seminar1MT,seminar1MT,seminar1MT|cc4A,nop,adbms1MT,adbms1MT,nop,nop,nop,nop|nop,nop,nop,nop,nop,nop,nop,adbms1MT|nop,nop,nop,nop,nop,nop,nop,nop', '4A|1MT', 'M RamaKrishna Murthy'),
('ANIL0422', 'cd3A,nop,nop,wt3C,nop,nop,nop,nop|wt3C,nop,cd3A,nop,nop,nop,nop,nop|nop,nop,nop,cd3A,nop,wt3C,nop,nop|nop,wt3C,nop,cd3A,nop,ostlab3C,ostlab3C,ostlab3C|nop,ostlab3C,ostlab3C,ostlab3C,nop,nop,wt3C,nop|nop,cd3A,nop,nop,nop,nop,nop,nop', '3A|3C', 'S Priyanka'),
('ANIL0423', 'pswithc1B,nop,nop,cd3B,nop,selab3A,selab3A,selab3A|nop,cd3B,nop,nop,pswithclab1B,pswithclab1B,pswithclab1B,nop|cd3B,nop,nop,nop,nop,pswithc1B,nop,nop|nop,cd3B,nop,nop,pswithc1B,nop,nop,nop|nop,pswithc1B,nop,cd3B,nop,nop,nop,nop|nop,nop,nop,nop,pswithc1B,nop,nop,nop', '1B|3B|3A', 'N Lokeswari'),
('ANIL0455', 'flat2C,nop,nop,nop,nop,nop,nop,nop|cpEE3C,nop,flat2C,nop,pswithclab1B,pswithclab1B,pswithclab1B,nop|flat2C,nop,nop,nop,pswithclab1C,pswithclab1C,pswithclab1C,nop|nop,flat2C,nop,cpEE3C,nop,nop,nop,nop|nop,nop,nop,flat2C,nop,nop,cpEE3C,nop|cpEE3C,cpEE3C,nop,nop,nop,nop,nop,nop', '2C|3C', 'G Sathar'),
('ANIL0531', 'nop,se3C,nop,ads3A,nop,nop,nop,nop|nop,nop,se3C,nop,nop,ads3A,nop,nop|ads3A,nop,nop,se3C,nop,nop,nop,nop|nop,ads3A,nop,se3C,nop,selab3C,selab3C,selab3C|nop,selab3C,selab3C,selab3C,nop,se3C,nop,nop|nop,nop,nop,ads3A,nop,nop,nop,nop', '3A|3C', 'T Krishnanjaneyulu'),
('ANIL0532', 'ca3C,mpilab2C,mpilab2C,mpilab2C,nop,nop,nop,nop|nop,ca3C,nop,mpi2C,nop,nop,nop,nop|nop,nop,ca3C,nop,nop,mpi2C,nop,nop|nop,nop,mpi2C,nop,nop,mpilab2C,mpilab2C,mpilab2C|ca3C,nop,nop,nop,nop,nop,mpi2C,nop|mpi2C,nop,ca3C,nop,nop,nop,nop,nop', '2C|3C', 'Ch Rupesh'),
('ANIL0537', 'cpEE3B,nop,ads3B,nop,pswithclab1A,pswithclab1A,pswithclab1A,nop|ads3B,nop,nop,cpEE3B,nop,nop,nop,nop|pswithclabECE1C,pswithclabECE1C,pswithclabECE1C,nop,nop,ads3B,nop,nop|nop,nop,ads3B,nop,nop,nop,nop,nop|nop,cpEE3B,nop,nop,nop,ads3B,nop,nop|nop,nop,nop,nop,nop,cpEE3B,cpEE3B,nop', '1A|3B', 'B Mahesh'),
('ANIL0546', 'toc1MT,toc1MT,nop,nop,nop,nop,pswithcECE1C,nop|pswithcECE1C,nop,nop,nop,nop,nop,nop,toc1MT|pswithcECE1Clab,pswithcECE1Clab,pswithcECE1Clab,nop,nop,nop,pswithcECE1C,nop|nop,oslab2C,oslab2C,oslab2C,pswithcECE1C,nop,nop,nop|nop,nop,nop,nop,nop,nop,toc1MT,toc1MT|pswithcECE1C,nop,nop,nop,nop,nop,nop,nop', '1MT|2C|1C', 'N Kiran Relangi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leavetable`
--
ALTER TABLE `leavetable`
  ADD PRIMARY KEY (`leaveid`),
  ADD KEY `EmployeeId` (`EmployeeId`);

--
-- Indexes for table `requesttable`
--
ALTER TABLE `requesttable`
  ADD PRIMARY KEY (`RequestId`),
  ADD KEY `FromEmpId` (`FromEmpId`),
  ADD KEY `ToEmpId` (`ToEmpId`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD KEY `EmployeeId` (`EmployeeId`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`EmployeeId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leavetable`
--
ALTER TABLE `leavetable`
  MODIFY `leaveid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `requesttable`
--
ALTER TABLE `requesttable`
  MODIFY `RequestId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `leavetable`
--
ALTER TABLE `leavetable`
  ADD CONSTRAINT `leavetable_ibfk_1` FOREIGN KEY (`EmployeeId`) REFERENCES `signup` (`EmployeeId`);

--
-- Constraints for table `requesttable`
--
ALTER TABLE `requesttable`
  ADD CONSTRAINT `requesttable_ibfk_1` FOREIGN KEY (`FromEmpId`) REFERENCES `signup` (`EmployeeId`),
  ADD CONSTRAINT `requesttable_ibfk_2` FOREIGN KEY (`ToEmpId`) REFERENCES `signup` (`EmployeeId`);

--
-- Constraints for table `signup`
--
ALTER TABLE `signup`
  ADD CONSTRAINT `signup_ibfk_1` FOREIGN KEY (`EmployeeId`) REFERENCES `timetable` (`EmployeeId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
