if(!isset($_SESSION["login"]))
	{
		header("Location:LOG.php");
	}
	if(isset($_SESSION["login"]))
	{
		if($_SESSION["time"] <= time())
		{
			header("Location:leavehome.php");
		}
	}
	
$num = mysqli_num_rows($query1);
		if($num == 1)
		{
			$_SESSION["login"] = true;
			$_SESSION["name"] = $name;
			$_SESSION["time"] = time()+30;
			header("Location:facultyform.php");
		}