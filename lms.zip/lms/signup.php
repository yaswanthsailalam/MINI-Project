<?php
session_start();
$connect = mysqli_connect("localhost","root","","lms");
if(!$connect)
{
	echo "failed";
}
       if(isset($_POST['submit']))
      {
	$fname   = 	$_POST['Name'];
	$mno     = 	$_POST['MobileNumber'];
	$mbno    = 	$_POST['MobileNumber2'];
	$emailid = 	$_POST['email2'];
	$empid   = 	$_POST['empid'];
	$pass    = 	$_POST['password'];
	$cpass   = 	$_POST['ConfirmPassword'];
	$usertype    =  $_POST['UserType'];

	$s = "INSERT INTO `signup`(`FirstName`, `MobileNumber`, `MobileNumber2`, `EmailId`, `EmployeeId`, `Password`, `ConfirmPassword`, `UserType`) VALUES('$fname','$mno','$mbno','$emailid','$empid','$pass','$cpass','$usertype')";
	if(mysqli_query($connect,$s))
	{
	echo "Registered Successfully.....Check your mail you given";
		$_session['EmailId'] = $emailid;
        $otp=rand(100000,999999);
        $sub="E-LEAVE Website";
        $msg="Hiii.. :$fname 
                 You have successfully registered for E-Leave Website.
                 keep remember your details for further
                         THANK YOU";
        mail($emailid,$sub,$msg);
     }
	  }
?>
<?php 

?>
<!DOCTYPE html>
<html>
<head>
<title>Registration form</title>
<style>
Body{  
  font-family:cursive;  
  background-color: palegreen; 
}
form{
}
button {   
       
        text-align:center;
        background-color:green;
        width:120px;
        height:50px;
        font-size:20px;
        color:black;   
        padding: 15px;   
        margin: 10px 0px;   
        border: none;  
        cursor: pointer;  
         }
.container {
        width: 50%;
        height:auto;
        padding: 16px;
        font-size:17px;
        text-align:left;
        color:black;
        background-color:white;
        margin-left:20%;
        
    }
  label {
  display: block;
  margin-bottom: 8px;
}
label.light {
  font-weight: 300;
  display: inline;
}
  .bg{  
  background-image: url('background1.png');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
}
input[type=text], input[type=password],input[type=email],input[type=number],input[type=typ],select {
  background: rgba(255,255,255,0.1);
  border: none;
  font-size: 16px;
  height: auto;
  margin: 0;
  outline: 0;
  padding: 13px;
  width: 85%;
  background-color: #e8eeef;
  color: black;
  box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
  margin-bottom: 30px;
  margin-left:20px;
}
input:hover,select:hover
{
  background-color:#333;
  color:white;
  transition: (1.1);
  opacity:0.9;
}
</style> 
<script>
   function validate()
   { 
      var name = document.signup.Name.value;
      var mbno = document.signup.MobileNumber.value; 
      var email = document.signup.email2.value;
      var empid = document.signup.empid.value;   
      var password = document.signup.password.value;
      var conpassword= document.signup.ConfirmPassword.value;
      if(name==null || name=="")
      {
	        alert("Name Can't be Blank");
          return false;
      }
      if (email==null || email=="")
      { 
          alert("Email can't be blank"); 
          return false; 
      }
      var emailid = "^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\.)?[a-zA-Z]+\.)?(anits)\.edu\.in$";
		  if((email.match(emailid)))
		  {
          alert("Invalid format");
          return false;
      }
      if (mbno==null || mbno=="")
	    {
          alert("phone number can't be empty");
          return false;
      }
	    var phoneno = "[6-9]{1}[0-9]{9}";
		  if(!(mbno.match(phoneno)))
		  {
          alert("invalid number");
          return false;
      }
      if(password.length < 6)
      { 
          alert("Password must be at least 6 characters long."); 
          return false; 
      } 
      if (password!=conpassword)
      { 
          alert("Confirm Password should match with the Password"); 
          return false; 
     }  
      return true;
     } 
</script>   
</head>
<body class="bg">
<center><h1>REGISTRATION FORM</h1></center>
<div class="container">
<form id="signup-form" onsubmit="return validate();" name="signup" action="signup.php" method="POST">
    <lable for="name">Name</lable></br>
       <input type="text" placeholder="Name" id="Name" name="Name"></br>

    <lable for="num">Mobile Number </lable>
        <input type="text"  placeholder="Enter mobile number" id="num" name="MobileNumber"></br>

    <lable for="num2">Mobile Number2(Optional) </lable>
        <input type="text"  placeholder="Enter alternate mobile number" id="num2" name="MobileNumber2"></br>

    <lable for="email2">E-Mail </lable><br>
        <input type="email" placeholder="Enter your email" id="email2" name="email2"></br>

    <lable for="empid">EMPLOYEE ID </lable>
      <input type="text" placeholder="Example   ANIL1234" id="empid" name="empid"></br>

    <lable for="pass">PASSWORD </lable>
       <input type="password"  placeholder="Enter password " id="pass1" name="password"></br>
       <input type="checkbox" onclick="myFunction()">Show Password</br>

    <lable for="pass2">CONFIRM PASSWORD</lable>
         <input type="password" placeholder="confirm password" id="pass2" name="ConfirmPassword"></br>

    <label for="UserType">Choose UserType</label>
          <select name="UserType" id="usertype" placeholder="usertype"></br>
              <option value="PRINCIPLE">PRINCIPLE</option>
              <option value="HOD">HOD</option>
              <option value="ADMIN">ADMIN</option>
              <option value="FACULTY">FACULTY</option>
          </select>               
  <center><button style="margin-left:80%" type="submit" name="submit">Submit</button></center>
</form>
</div>
<a href="leavehome.php"><button style="margin-left:20%">Cancel</button></a>
</center>
</body>
</html>