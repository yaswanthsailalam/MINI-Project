<?php
	$connect = mysqli_connect("localhost","root","","lms");
	if(!$connect){
		echo "failed";
	}
		   if(isset($_POST['submit']))
		  {

			  $empid = $_POST['empid'];
			  $time = $_POST['time'];
			  $section = $_POST['section'];
			  $Name = $_POST['Name'];
			  for($i=0;$i<count($empid);$i++)
			  {
			  $s = "INSERT INTO `timetable` VALUES('$empid[$i]','$time[$i]','$section[$i]','$Name[$i]')";
			  
			  $result = mysqli_query($connect,$s);
			  }
			  echo "Saved Sucessfully!!!";
		  }
?>
<!DOCTYPE html>
<html>
	<head>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Alegreya+Sans:800');

		body{
			font-family: 'Alegreya Sans', sans-serif;
			overflow-x: hidden;
		}
		.button {
              border-radius:10px;
              outline: 0;
			  padding: 15px;
			  color: white;
			  background-color: #000;
			  text-align: center;
			  cursor: pointer;
			  width:auto;
			  float:right;
			  margin:0 10px;
}

		.nav{
			height: 100%;
			width: 0;
			position: fixed;
			z-index: 1;
			top: 0;
			left: 0;
			background-color: #111;
			opacity: .9;
			overflow-y: hidden;
			padding-top: 60px;
			transition: 0.7s;
		}
		.nav a {
			display: block;
			padding: 20px 30px;
			font-size: 25px;
			text-decoration: none;
			color: #ccc;
		}
		.nav a:hover{
			color:#fff;
			transition: : 0.4s;
		}
		.nav .close{
			position: absolute;
			top: 0;
			right: 22px;
			margin-left: 50px;
			font-size: 30px;
		}
		.slide a{
			color: #000;
			font-size: 30px;
		}
		#content{
			padding: 20px;
			transition: margin-left 0.7s;
		}
		h2 {
		  animation: color-change 1s infinite;
		  font-style:italic;
		}

		@keyframes color-change {
		  0% { color: #eb0000; }
		  50% { color: 	#D22B2B; }
		  100% { color: #8B0000; }
		}
		.abc{
			background-color: white;
			color: black;
			width: 60%;
			height: 200px;
			border-radius: 25px;
			margin-left: 15%;
			display:none;
		}
		#myTable{
			font-size: 20px;
			border-width:5px;
			background-color:white;
		}
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
			$("#new").click(function(){
				var add="<tr>"
					 add+="<td><input type='varchar' name='empid[]' placeholder='Enter id'</td>"
					 add+="<td><input type='text' name='time[]' placeholder='enter timetable'</td>"
					 add+="<td><input type='text' name='section[]' placeholder='enter section'</td>"
					 add+="<td><input type='text' name='Name[]' placeholder='enter name'</td>"
					 add+="</tr>";
					 $("table tbody").append(add);
					 });
				$('#rem').click(function(){
					$('#myTable tr:last').remove();
				})
				});
			</script>
	</head>
	<body style="background-color:grey;">
	<script>
        function openSlideMenu()
        {
            document.getElementById('menu').style.width = '250px';
            document.getElementById('content').style.marginLeft = '250px';
        }
        function closeSlideMenu()
        {
            document.getElementById('menu').style.width = '0';
            document.getElementById('content').style.marginLeft = '0';
        }
    </script>
    <div id="content">
    	<a href="ADMIN.php"><button class="button">BACK</button></p></a>
	<form method="POST"  action="ttinsertion.php">
	<center>
		<h1><b>Enter Details of Faculty<b></h1>
		<table border="1" id="myTable">
			<thead>
				<tr>
					<th>Faculty ID</th>
					<th style=width:350px;>Faculty TimeTable</th>
					<th style=width:200px;>Section</th>
					<th style=width:200px;>Faculty Name</th>
				</tr>
			</thead>
			<tbody></tbody>
			<tfoot></tfoot>
		</table>
		
		</br></br>
		
		<td><input type="button" value="Add" id="new" style="font-size:25px;border-radius: 10px;color:blue;background-color:white">
		&nbsp; &nbsp;
		<button type="button" onclick="myDeleteFunction()"id="rem" style="font-size:25px;border-radius: 10px;color:red;background-color:white">Delete</button></td>
	</center>
	</br>
	<center>
		<input type="submit" name="submit"  value="Save" id="new" style="font-size:25px;border-radius: 10px;color:green;background-color:white">
	</center>
	</form>
</body>
</html>