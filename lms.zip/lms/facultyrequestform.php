<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
body {
  margin:0;
  font-family:cursive;
}

.menu {
  overflow: hidden;
  background-color: #333;
  margin:0;
}

.menu a {
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.menu .icon {
  display: none;
}

a:hover{
  opacity:0.7;
  transition: (1.1);
  background-color:white;
  color:black;
}


}
.header{
  width:100%;
  font-family:cursive;
  font-size:20px;
  margin: 0;
  text-align:center;
  color:black;
}
.bg{
  background-image: url('background1.png');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
}

.head{
  text-align: center;
  color:white;

}

button {
  background-color:#333;
  color: white;
  cursor: pointer;
  width: 100px;
  display:inline-block;
  text-align:center;
}

button:hover {
  opacity: 0.7;
  transition: (1.1);
}





.hod{
position:absolute;
display:block;
}
table,th,td{
border:1px solid black;
}

.table{
  width:90%;
  margin: 10px 0 0 30px;
}
</style>
</head>
<body class="bg">


</div>
<div class="menu" id="myTopnav">
  <h1 style="color:white;float:left;font-size: 30px;"><center>Anits E-Leave Management</center></h1>
  <a href="facultyform.php"></i>Back</a> 
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Back" below if you want to exit this Page.</div>
            <div class="modal-footer">
              <button class="btn btn-warning" type="button" data-dismiss="modal">Cancel</button>
              <form action="logout1.php" method="POST"> 
                <button type="submit" name="logout_btn" class="btn btn-primary">Back</button>
              </form>
            </div>
              </div>
          </div>
</div>
<div class="hodbuttons">
						<?php
						SESSION_start();
                        $con=mysqli_connect('localhost','root',"","lms");
                        if(!$con)
                        {
                          echo "db not connected";
                        }
                        $s="select * from requesttable where ToId='$_SESSION[name]' and Status ='pending'";							
                        $query=mysqli_query($con,$s);
                        while($row=mysqli_fetch_assoc($query))
                        {
                        ?>
                        <table class="table">
                          <tr>
                              <th>FromId</th>
                              <th>ToId</th>
                              <th>Section</th>
                              <th>Period</th>
                              <th>DAY</th>
                              <th>Date</th>
                              <th>status</th>
                          </tr>
                           <tr>
                               <td><?php echo $row['FromId']?></td>
                               <td><?php echo $row['ToId']?></td>
                               <td><?php echo $row['Section']?></td>
                               <td><?php echo $row['Period']?></td>
                               <td><?php echo $row['Day']?></td>
                               <td><?php echo $row['Date']?></td>
                               <td> <form action="facultyrequestform.php" method="post">
                              <center><button name='app' type="submit" value="<?php echo $row['RequestId']?>" id='grant'><p>Grant</p></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              <button name='dis' type="submit" value="<?php echo $row['RequestId']?>"><p>Reject</p></button></center>
                            </form></td>

                           </tr>
                        </table>
						  
                        <?php
                        }
                    ?>
                     <?php

                        if(isset($_POST['app']))
                        {
                            $query=$_POST['app'];
                            $s="update requesttable set Status='Approved' where RequestId =$query";
							
                            $res=mysqli_query($con,$s);
							$s =  "select * from requesttable where RequestId=$query";
							$res=mysqli_query($con,$s);
							$row = mysqli_fetch_assoc($res);
							$s1 = "select * from signup where FirstName = '$row[FromId]'";
							$res1=mysqli_query($con,$s1);
							$row1 = mysqli_fetch_assoc($res1);							
							$sub="E-LEAVE Website";
							$x = $row['FromId'];
						
							$msg="Hello '$row[FromId]',
								'$row[ToId]' has accepted the class '$row[Period]' on '$row[Date]' you requested
								please login to confirm their acceptance the details.
										THANK YOU";
							
							mail($row1['EmailId'],$sub,$msg);
							echo '<script>window.location.href="facultyrequestform.php"</script>';
                        }
                        if(isset($_POST['dis']))
                        {
                            $query=$_POST['dis'];
                            $s="update requesttable set Status='Disapproved' where RequestId =$query";
							
                            $res=mysqli_query($con,$s);
							$s =  "select * from requesttable where RequestId=$query";
							$res=mysqli_query($con,$s);
							$row = mysqli_fetch_assoc($res);
							$s1 = "select * from signup where FirstName = '$row[FromId]'";
							$res1=mysqli_query($con,$s1);
							$row1 = mysqli_fetch_assoc($res1);							
							$sub="E-LEAVE Website";
							$x = $row['FromId'];
							
							$msg="Hello '$row[FromId]',
								'$row[ToId]' has rejected the class '$row[Period]' on '$row[Date]' you requested
								please login to confirm their acceptance the details.
										THANK YOU";
							
							mail($row1['EmailId'],$sub,$msg);
							$s =  "delete from requesttable where RequestId=$query";
							$res=mysqli_query($con,$s);
                        }
			
                        ?>
  
</div>
<script>
$(document).ready(function(){
	$('#grant').click(function(){
		(this).css('color','red');
	})
})
</script>
</body>
</html>

