<?php
    session_start();
    if(isset($_POST['app']))
  {
        $query=$_POST['app'];
        $s="update leavetable set HODStatus='Approved' where EmployeeId ='$query'";
        $res=mysqli_query($con,$s);
        echo '<script>window.location.href="hodform.php"</script>';
    }
    if(isset($_POST['dis']))
    {
        $query=$_POST['dis'];
        $s="update leavetable set HODStatus='disapproved' where EmployeeId='$query'";
        $res=mysqli_query($con,$s);
        echo '<script>window.location.href="hodform.php"</script>';
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>ADMIN PAGE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
  <style>
    @import url('https://fonts.googleapis.com/css?family=Alegreya+Sans:800');

    body{
      font-family: 'Alegreya Sans', sans-serif;
      overflow-x: hidden;
      background-color: #ffffcc;
    }
    .header{
  font-size:30px;
  text-align:center;
  color:black;
  float: left;
  display: inline-block;
  font-family:'Alegreya Sans', sans-serif;
  margin-left: 20%;
}
 .header h1{
  font-size: 2em;
  font-weight: 900;
  color:red;
}
h1 span{
  color:navy;
}
    .nav{
      height: 100%;
      width: 0;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #111;
      opacity: .9;
      overflow-y: hidden;
      padding-top: 60px;
      transition: 0.7s;
    }
    .nav a {
      display: block;
      padding: 20px 30px 20px;
      font-size: 25px;
      text-decoration: none;
      color: #ccc;
    }
    .nav a:hover{
      color:#fff;
      transition: : 0.4s;
      opacity:0.7;
    }
    .nav .close{
      position: absolute;
      top: 0;
      right: 22px;
      margin-left: 50px;
      font-size: 30px;
    }
    .slide a{
      color: #000;
      font-size: 30px;
      float: right;
    }
    #content{
      padding: 20px;
      transition: margin-left 0.7s;
    }
    h2 {
      animation: color-change 1s infinite;
      font-style:italic;
    }

    @keyframes color-change {
      0% { color: #eb0000; }
      50% { color:  #D22B2B; }
      100% { color: #8B0000; }
    }

    .cards
    {   
      display: block;
      width:60%;
      height:200px;
      margin-top: 15%;
      margin-left:20%;
    }
    .leftt{
      width:45%;
       background-color:white;
      display: inline-block;
      height: 220px;
      float: left;
      border-radius: 25px;
      box-shadow:1px 15px 10px 1px black;
    }
    .rightt{
      width: 45%;
      display: inline-block;
      background-color:white;
      height: 220px;
      float: right;
      border-radius: 25px;
      box-shadow:1px 15px 10px 1px black;
    }
    .rightt img,.leftt img{
      width:200px;
      height: 160px;
      margin-left:20%;
    }
    .rightt:hover,.leftt:hover{
      background-color:#cce6ff;
      color: white;
      transition: : 1s;
    }
    .profile{
    width:55%;
    height:380px;
    border-radius: 25px;
    background-color: white;
      color:black;
      margin-left:26%;
      margin-top:10%;
      box-shadow:0px 10px 10px 0px black;
      display:none;
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  overflow: auto; /* Enable scroll if needed */
  padding-top: 60px;
  font-family:sans-serif;
  }
  .profile label{
    color:red;
    font-size:20px;
    margin-left:5%;

  }
  .profile p{
      margin-left:5%;
      color:navy;
      font-size: 15px;
      width:85%;
      background-color:#f2f2f2;
      padding:5px;
      border-radius:20px;
  }
  .left{
    margin-top:0;
    width:50%;
    height:78%;
    display: inline-block;
    float:left;
  }
  .right{
    width:50%;
    height:78%;
    margin-top:0;
    float:right;
    display:inline-block;
    
  }
.profile button {
  display: inline-block;
  padding: 13px;
  color: white;
  font-size:15px;
  background-color:navy;
  text-align: center;
  width:80px;
  float:right;
  margin:0 15px 0px;
  border-radius:10px;
}
  .pro{
   width:55%;
    height:380px;
    border-radius: 25px;
    background-color: white;
      color:black;
      margin-left:26%;
      margin-top:10%;
      box-shadow:0px 10px 10px 0px black;
      display:none;
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  overflow: auto; /* Enable scroll if needed */
  padding-top: 60px;
  font-family:sans-serif;
  }
  .pro label{
    color:red;
    font-size:20px;
    margin-left:5%;

  }
  .pro input{
      margin-left:5%;
      color: navy;
      font-size: 18px;
      width:85%;
      background-color:#f2f2f2;
      padding:5px;
      border-radius: 10px;
  }
.pro button {
   display: inline-block;
  padding: 13px;
  color: white;
  font-size:15px;
  background-color:navy;
  text-align: center;
  width:80px;
  float:right;
  margin:0 15px 0px;
  border-radius:10px;
}
.hodbuttons{
  margin-top:13%;
  margin-left:8%;
}
form{
  margin-left:10%;
  display: block;
}
.form input[type="text"]{
width:300px;
padding: 10px;
color: navy;
border-radius: 10px;
float: right;
}
.form input[type="submit"]{
width:100px;
padding: 10px;
color:white;
border-radius: 10px;
background: navy;
float: right;
}
</style>
</head>
<body>
  <div class="rks">
    <script>
      function openSlideMenu()
      {
        document.getElementById('menu').style.width = '250px';
        document.getElementById('content').style.marginLeft = '100px';
      }
      function closeSlideMenu()
      {
        document.getElementById('menu').style.width = '0';
        document.getElementById('content').style.marginLeft = '0';
      }
    </script>
    
    <div id="content">
            
      <span class="slide">
        <a href="#" onclick="openSlideMenu()">
          <i class="fas fa-bars"></i>
        </a>
      </span>
      <div class="header">
                    <centre><h1><span>ANITS</span> E-Leave <span> Management</span></h1></centre>
          </div>
          <h5 style="float:left; color:black; font-size:25px; margin-top:70px;margin-left:15%;display: block"><b>WELCOME <?php echo $_SESSION['name']; ?></b></h5>
      <div id="menu" class="nav">
        <a href="#" class="close" onclick="closeSlideMenu()">
          <i class="fas fa-times"></i>
        </a>
		 <a href="confirmform.php">Confirm</a>
         <a href="#"onclick="location.replace('hodleaveapply.php')" type="submit">Apply for LEAVE</a>
         <a href="#" onclick="document.getElementById('id01').style.display='block'" onclick="myFunction()" style="width:auto;">Profile</a>
        <a href="#" data-toggle="modal" data-target="#logoutModal"><i class="fas fa-sign-out-alt"></i>Logout</a> 
      </div>
      <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
              </div>
              <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
              <button class="btn btn-warning" type="button" data-dismiss="modal">Cancel</button>
              <form action="logout.php" method="POST"> 
              <button type="submit" name="logout_btn" class="btn btn-primary">Logout</button>
              </form>
            </div>
              </div>
            </div>
  </div>
  <div class="hodbuttons">
<form action="hodform.php" method="post" class="form">
  <input type="submit" name="submit" >
<input type="text" name="facname">

</form>

<?php
                        $con=mysqli_connect('localhost','root',"","lms");
                        if(!$con)
                        {
                          echo "db not connected";
                        }
                        if(isset($_POST['submit']))
                        {
                          $v=$_POST['facname'];
                          
                        $s="select * from leavetable where Name='$v' and HODStatus='Pending'";  
                        $query=mysqli_query($con,$s);
                        $row=mysqli_fetch_assoc($query)
                        
                        ?>
                        <div style="background-color:white;width:70%;margin-left:15%; border:2px solid black;padding:10px">
                        <div style="width:100%"><img src="yas.jpg" width=100% height=200px alt=""></div>
                         <div>
                         <center><h2>Leave Letter</h2></center>
                         <div style="float:right;"><h3>Date:<?php echo date('Y-m-d')?></h3></div>
                         <div style="folat:left;margin-top:60px"><h3><?php echo $v?></h3></div>
                         <div style="width:40%">
                         <div style="float:right;margin-top:-20px"><h3><b>To:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row['To']?></h3></div>
                         <div style="folat:left;"><h3><b>From:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo  $row['From']?></h3></div>
                         </div>
                         <div>
                         <h3><b>Reason:</b></h3>
                         <div>
                         <h3>
							&nbsp;&nbsp;&nbsp;&nbsp;<?php echo  $row['Description']?>
                         </h3>
                         </div>
                         </div>
                        
                        <div style="widht:80%;">
                        <h3><b>Replacements:</b></h3>
                        <center>
                        <table class="table" >
                          <tr style="background-color:black;color:white">
                              <th>TO</th>
                              <th>DATE</th>
                              <th>SECTION</th>
                              <th>PERIOD</th>
                              
                          </tr>
                          <?php
                           $date1=$row['From'];
                          $date2=$row['To'];
                          for($daa=$date1;$daa<=$date2;$daa++)
                          {
                        $s="select * from requesttable where FromId='$v' and Date='$daa'";
              
                        $query=mysqli_query($con,$s);
                        while($row1=mysqli_fetch_assoc($query))
                        {
                          ?>
                      
                           <tr>
                               <td><?php echo $row1['ToId']?></td>
                               <td><?php echo $row1['Date']?></td>
                               <td><?php echo $row1['Section']?></td>
                               <td><?php echo $row1['Period']?></td>
                               

                           </tr>
                        
              
                        <?php
                        }

                        }
                        echo "</table>";
                        ?>
                        </center>
                        </div>
                        <br>
                        <br>
                        <div>
                        <form action="hodform.php" method="post">
<center><button name='app' type="submit" value="<?php echo $row['EmployeeId']?>"><p>Grant</p></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button name='dis' type="submit" value="<?php echo $row['EmployeeId']?>"><p>Reject</p></button></center>
</form></div><?php
                      }
                    ?>
                    </div>
                    </div>
                    
                     <?php

                        if(isset($_POST['app']))
                        {
                            $query=$_POST['app'];
                            $s="update leavetable set HODStatus='Approved' where EmployeeId ='$query'";
                            $res=mysqli_query($con,$s);
                            $s="select * from leavetable  where EmployeeId ='$query'";
                            $res=mysqli_query($con,$s);
                            $row=mysqli_fetch_assoc($res);
                            $y='yaswanthsailalam@gmail.com';
  
  $sub="E-LEAVE Website";
  $sub="E-LEAVE Website";
  $msg="Hello principal sir ,
This is '$row[Name]' , applied for a leave from '$row[From]' to '$row[To]'. Approved By HOD please log on to know more details ";
  
    echo $msg;
        mail($y,$sub,$msg);
                           
                        }
                        if(isset($_POST['dis']))
                        {
                            $query=$_POST['dis'];
                            $s="update leavetable set HODStatus='disapproved' where EmployeeId='$query'";
                            $res=mysqli_query($con,$s);
                            echo '<script>window.location.href="hodform.php"</script>';
                        }
                        ?>

</div>
  <div class="profile" id="id01">
                     <?php
                        $a=$_SESSION['empid'];
                        $s="select * from signup where EmployeeId='$a'";  
                        $query=mysqli_query($con,$s);
                        $row=mysqli_fetch_assoc($query);
                        
                        ?>
                        <div class="left">
                               <label>Name</label>
                                 <p><?php echo $row['FirstName']?></p>  
                               <label>Phone number2</label>
                                 <p><?php echo $row['MobileNumber2']?></p>
                                     <label>Employee ID</label>
                                 <p> <?php echo $row['EmployeeId']?></p>
                         </div>
                         <div class="right">
                           <label>Phone number</label>
                                  <p> <?php echo $row['MobileNumber']?></p>
                                 <label>Email</label>
                                  <p><?php echo $row['EmailId']?></p>
                               <label>User Type</label>
                                <p><?php echo $row['UserType']?></p>
                        </div>
                           <a  href="#" onclick="document.getElementById('id02').style.display='block'" ><button>Edit</button></a>
                        <button style="float:left;display: inline-block;padding: 13px;color: white;background-color: navy;text-align: center;width:90px;margin:0 0 5px 15px;"  onclick="document.getElementById('id01').style.display='none'" title="Close Modal">Cancel</button>
              
                        <?php
                        
                    ?>
</div>

<div class="pro" id="id02">
                    <form method="POST" action="edit profile.php">
                        <div class="left">
                               <label>Name</label>
                               <br></br>
                                  <input type="text" placeholder="Name" value="<?php echo $row['FirstName']?>" id="Name" name="Name">
                                  <br></br>
                               <label>Phone number2</label>
                               <br></br>
                               <input type="text"  placeholder="Enter alternate mobile number" value="<?php echo $row['MobileNumber2']?>" id="num2" name="MobileNumber2" pattern="[6-9]{1}[0-9]{9}">
                               <br></br>
                         </div>
                         <div class="right">
                           <label>Phone number</label>
                           <br></br>
                                 <input type="text"  placeholder="Enter mobile number" value="<?php echo $row['MobileNumber']?>" id="num" name="MobileNumber" pattern="[6-9]{1}[0-9]{9}">
                                 <br></br>
                                 <label>Email</label>
                                 <br></br>
                                   <input type="email" placeholder="Enter your email" value="<?php echo $row['EmailId']?>" id="email2" name="email2" pattern="^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\.)?[a-zA-Z]+\.)?(anits)\.edu\.in$">
                                   <br></br>
                          </div>
                           <button type="submit">Save</button>
                      </form>
                         
                       <button style="float:left;display: inline-block;padding:13px;color: white;background-color:navy;text-align: center;width:100px;"  onclick="document.getElementById('id02').style.display='none'" title="Close Modal">Cancel</button>
        </div>
</div>
<script>
var modal = document.getElementById('id01');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
<script>
var modal = document.getElementById('id02');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</script>
</body>
</html>