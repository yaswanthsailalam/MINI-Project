<?php
	$con = mysqli_connect("localhost","root","","lms");
	if(!$con)
	{
	  echo "failed";
	}
	
	$sql = "select * from timetable where Id='ANIL0084'";
	$query = mysqli_query($con,$sql);
	$row = mysqli_fetch_assoc($query);
	echo $row['tt'];
?>