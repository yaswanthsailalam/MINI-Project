<?php
$connect = mysqli_connect("localhost","root","","lms");
if(!$connect){
	echo "failed";
}
	   session_start();
       $otp = $_SESSION["otp"];
	   if(isset($_POST['submit']))
      {
		$notp = $_POST["otp"];
		if($otp == $notp)
		{
			header("LOCATION: resetpassword.php");
		}
		else{
			echo "Invalid otp";
		}
	  }
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {font-family: cursive;}
form {border: 3px solid #f1f1f1;
 opacity:0.8;
 }

input[type=email], input[type=otp] ,input[type=userid]{
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
.formstyle{
  width: 40%;
  height: 50%;
  text-align: left;
  background-color: white;
  bottom:300px;


}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
.container {
  padding: 10px;
}

span.psw {
  float: right;
  padding-top: 16px;
}
.head{
  text-align: center;
  color:black;
}
.bg{
  background-image: url('background1.png');
  height: 100%; 
  width: 100%;
  background-repeat: no-repeat;
  background-size: cover;
  }
</style>
</head>
<body class="bg">
<div style = "position:fixed; left:30%; top:100px; background-color:white;text-align: left;width:40%;height:80%">

<form action="otp.php" method="POST">
  <div class="head">
    <h1>OTP</h1>
  </div>
  <div class="container">
    <label for="email"><b>OTP</b></label>
    <input type="number" placeholder="Enter OTP" name="otp">
    <button  type="submit" name="submit">verifyOTP</button>
   
  </div>
  </div>
</form>


</div>
</center>

</body>
</html>